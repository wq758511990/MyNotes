import React from 'react';
import AvatarDropdown from './AvatarDropdown';

const RightContent = () => {
  return <AvatarDropdown />;
};

export default RightContent;
