import React from 'react'
const AdminPage = () => {
    return <div>
        用户管理
    </div>
}

export default AdminPage