import request from 'umi-request';
import { message } from 'antd';

// 克隆响应对象做解析处理

request.interceptors.response.use(async (response, options) => {
  let result;
  const data = await response.clone().json();
  if (data.code !== '0') {
    // 界面报错处理
  } else {
    result = response;
  }
  return result as Response;
});
export default request;
