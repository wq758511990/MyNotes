import React from 'react'
const WelcomePage = () => {
    return <div>
        欢迎哟呵呵
    </div>
}

export default WelcomePage