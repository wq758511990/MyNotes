// @ts-nocheck

  import HomeOutlined from '@ant-design/icons/es/icons/HomeOutlined';
import SettingOutlined from '@ant-design/icons/es/icons/SettingOutlined';
import UsergroupAddOutlined from '@ant-design/icons/es/icons/UsergroupAddOutlined'
  export default {
    HomeOutlined,
SettingOutlined,
UsergroupAddOutlined
  }