import { defineConfig } from 'umi';
import routes from './routes';
import layoutSetting from './layoutSetting';

export default defineConfig({
  nodeModulesTransform: {
    type: 'none',
  },
  layout: layoutSetting,
  routes,
  fastRefresh: {},
});
