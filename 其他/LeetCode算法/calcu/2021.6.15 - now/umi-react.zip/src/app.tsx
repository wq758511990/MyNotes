import React from 'react';
import { history } from 'umi';
import RightContent from '@/components/RightContent';
import {
  BasicLayoutProps,
  Settings as LayoutSettings,
} from '@ant-design/pro-layout';

export async function getInitialState() {
  const fetchUserInfo = async () => {
    return undefined;
  }; // 如果是登录页面，不执行

  // if (history.location.pathname !== loginPath) {
  //   const currentUser = await fetchUserInfo();
  //   return {
  //     fetchUserInfo,
  //     currentUser,
  //     settings: {},
  //   };
  // }

  return {
    test: 1,
    settings: {},
  };
}

export const layout = ({
  initialState,
}: {
  initialState: { settings?: LayoutSettings; currentUser?: any };
}): BasicLayoutProps => {
  return {
    rightContentRender: () => <RightContent />,
    onPageChange: () => {
      const { currentUser } = initialState;
      const { location } = history;
      // 如果没有登录，重定向到 login
      //   if (!currentUser && location.pathname !== '/user/login') {
      //     history.push('/user/login');
      //   }
    },
    menuHeaderRender: undefined,
    ...initialState?.settings,
  };
};
