export default [
  {
    layout: false,
    path: '/login',
    component: '@/pages/login',
  },
  { path: '/', icon: 'home', component: '@/pages/index', name: '首页' },
  { path: '/admin', icon: 'setting', component: '@/pages/admin', name: '管理' },
  {
    path: '/welcome',
    icon: 'UsergroupAddOutlined',
    component: '@/pages/welcome',
    name: '欢迎',
  },
];
