import React from 'react'

const LoginPage = () => {
    return <div>
        登录
    </div>
}

export default LoginPage